<h2>Senior Management Support </h2>
<?php
$category=basename(__FILE__, '.php');
getQuestions($category);
?>

