osma
====

Open Source Maturity Assessment

Still in Beta but made available for assessment and general "playing with"


#### Database config
I've also included the dayabase structure.  Run:

mysql -u root -p < osma.sql

Don't forgot to change the mysql password in functions.php

#### Legal Stuff

OSMA is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

OSMA is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with OSMA.  If not, see <http://www.gnu.org/licenses/>.

** NOTE: All data within the customerDetails table is completely made up **
