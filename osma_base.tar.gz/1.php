<h2>General</h2>
<?php
$category=basename(__FILE__, '.php'); ;
getQuestions($category);
?>
