<h2>Development Standards and Tools</h2>
<?php
$category=basename(__FILE__, '.php');
getQuestions($category);
?>
