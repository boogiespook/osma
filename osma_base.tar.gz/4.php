<h2>Vertical Community Participation</h2>
<?php
$category=basename(__FILE__, '.php');
getQuestions($category);
?>

